import { View, Text } from "react-native";

const CVScreen = () => {
    return (
        <View>
            <Text>CV Screen</Text>
        </View>

    );
}
export default CVScreen;