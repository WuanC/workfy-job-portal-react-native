import { View, Text } from "react-native";

const ExploreScreen = () => {
    return (
        <View>
            <Text>Explore Screen</Text>
        </View>

    );
}
export default ExploreScreen;