import { View, Text } from "react-native";

const MessageScreen = () => {
    return (
        <View>
            <Text>Message Screen</Text>
        </View>

    );
}
export default MessageScreen;