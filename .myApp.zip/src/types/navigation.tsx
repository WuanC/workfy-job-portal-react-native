
export type RootStackParamList = {
  JobDetail: undefined
  JobSubmit: undefined
  JobSubmitSuccess: undefined
  Login: undefined
  MainApp: undefined
  SearchFilter: undefined
};
// type JobDetailNavigationProp = NativeStackNavigationProp<
//   RootStackParamList,
//   "JobDetail"
// >;